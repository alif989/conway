<?php

class BaseController {
	public static function getBlob() {
		return "Just a test";
	}
}